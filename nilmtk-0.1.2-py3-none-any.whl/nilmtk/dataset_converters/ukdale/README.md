Dataset converter for the UK-DALE dataset.

Details of the data set and a link to download the data can be found
at http://www.doc.ic.ac.uk/~dk3810/data/

Unlike most other NILMTK dataset converters, the YAML metadata for
UK-DALE is not included in NILMTK because the YAML metadata comes with
the UK-DALE dataset.  Hence the NILMTK UK-DALE converter uses the
metadata downloaded with the dataset.  If you want to see the UK-DALE
metadata on its own then it is available here:
https://github.com/JackKelly/UK-DALE_metadata

